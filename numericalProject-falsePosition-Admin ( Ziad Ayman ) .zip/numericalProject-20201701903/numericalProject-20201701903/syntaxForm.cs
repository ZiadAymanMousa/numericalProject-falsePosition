﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace numericalProject_20201701903
{
    public partial class syntaxForm : Form
    {
        public syntaxForm()
        {
            InitializeComponent();
        }

        private void operatorsSytaxbutton_Click(object sender, EventArgs e)
        {
            FormatsPictureBox.Visible = false;
            OperatorsPictureBox.Visible = !OperatorsPictureBox.Visible;
            functionsSyntaxLink.Visible = false;
        }

        private void numberFormartsbutton_Click(object sender, EventArgs e)
        {
            FormatsPictureBox.Visible = !FormatsPictureBox.Visible;
            OperatorsPictureBox.Visible = false;
            functionsSyntaxLink.Visible = false;
        }

        private void functionsSytaxButton_Click(object sender, EventArgs e)
        {
            FormatsPictureBox.Visible = false;
            OperatorsPictureBox.Visible = false;
            functionsSyntaxLink.Visible = !functionsSyntaxLink.Visible;
        }
    }
}
