﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Windows.Forms;
using org.mariuszgromada.math.mxparser;
using numericalProject_20201701903.classes;


namespace numericalProject_20201701903
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void falseRegaliaButton_Click(object sender, EventArgs e)
        {
           
            string expr = equationInputBox.Text;
      
            Fr.equ = new Function("y", expr, "x" );

            Fr.roundTo = (int)roundToNumBox.Value;
              
            if( MAXITTERS.Value <= 0)
            {
                Fr.MAX_ITER = 1000000;
            }
            else
            {
                Fr.MAX_ITER = (int)MAXITTERS.Value;
            }

            string syntaxchecker = Fr.checkSyntax();

            label5.Text = syntaxchecker;

            if (syntaxchecker == "calculating" )
            {
                try
                {
                    if (!Double.IsNaN(Convert.ToDouble(aRangeInputBox.Text)) || !Double.IsNaN(Convert.ToDouble(bRangeInputBox.Text)))
                    {
                        
                        label5.Text = Fr.falsePoint(Convert.ToDouble(aRangeInputBox.Text), Convert.ToDouble(bRangeInputBox.Text));
                    }
                    else label5.Text = "a and/or b is not a number";
                }
                catch(Exception eex)
                {
                    Debug.WriteLine(eex.Message);
                    label5.Text = "a and/ or b is not a number";
                }
            } 
        }

        private void syntaxButton_Click(object sender, EventArgs e)
        {
            syntaxForm syntaxform = new syntaxForm();
            syntaxform.Show();
        }
    }
}
