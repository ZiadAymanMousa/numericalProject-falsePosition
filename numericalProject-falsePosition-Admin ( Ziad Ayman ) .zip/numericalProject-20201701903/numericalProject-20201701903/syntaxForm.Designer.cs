﻿
namespace numericalProject_20201701903
{
    partial class syntaxForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(syntaxForm));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.operatorsSytaxbutton = new System.Windows.Forms.Button();
            this.numberFormartsbutton = new System.Windows.Forms.Button();
            this.FormatsPictureBox = new System.Windows.Forms.PictureBox();
            this.OperatorsPictureBox = new System.Windows.Forms.PictureBox();
            this.functionsSytaxButton = new System.Windows.Forms.Button();
            this.functionsSyntaxLink = new System.Windows.Forms.LinkLabel();
            ((System.ComponentModel.ISupportInitialize)(this.FormatsPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.OperatorsPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(66, 98);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(331, 315);
            this.label1.TabIndex = 0;
            this.label1.Text = resources.GetString("label1.Text");
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(66, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "summarised syntax";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(507, 23);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "full syntaxt forms";
            // 
            // operatorsSytaxbutton
            // 
            this.operatorsSytaxbutton.Location = new System.Drawing.Point(492, 54);
            this.operatorsSytaxbutton.Name = "operatorsSytaxbutton";
            this.operatorsSytaxbutton.Size = new System.Drawing.Size(75, 38);
            this.operatorsSytaxbutton.TabIndex = 3;
            this.operatorsSytaxbutton.Text = "operators\r\nallowed\r\n";
            this.operatorsSytaxbutton.UseVisualStyleBackColor = true;
            this.operatorsSytaxbutton.Click += new System.EventHandler(this.operatorsSytaxbutton_Click);
            // 
            // numberFormartsbutton
            // 
            this.numberFormartsbutton.Location = new System.Drawing.Point(573, 54);
            this.numberFormartsbutton.Name = "numberFormartsbutton";
            this.numberFormartsbutton.Size = new System.Drawing.Size(106, 38);
            this.numberFormartsbutton.TabIndex = 4;
            this.numberFormartsbutton.Text = "supported \r\nnumber formats";
            this.numberFormartsbutton.UseVisualStyleBackColor = true;
            this.numberFormartsbutton.Click += new System.EventHandler(this.numberFormartsbutton_Click);
            // 
            // FormatsPictureBox
            // 
            this.FormatsPictureBox.Enabled = false;
            this.FormatsPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("FormatsPictureBox.Image")));
            this.FormatsPictureBox.Location = new System.Drawing.Point(451, 98);
            this.FormatsPictureBox.Name = "FormatsPictureBox";
            this.FormatsPictureBox.Size = new System.Drawing.Size(391, 408);
            this.FormatsPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.FormatsPictureBox.TabIndex = 5;
            this.FormatsPictureBox.TabStop = false;
            this.FormatsPictureBox.Visible = false;
            // 
            // OperatorsPictureBox
            // 
            this.OperatorsPictureBox.Enabled = false;
            this.OperatorsPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("OperatorsPictureBox.Image")));
            this.OperatorsPictureBox.Location = new System.Drawing.Point(443, 98);
            this.OperatorsPictureBox.Name = "OperatorsPictureBox";
            this.OperatorsPictureBox.Size = new System.Drawing.Size(399, 416);
            this.OperatorsPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.OperatorsPictureBox.TabIndex = 6;
            this.OperatorsPictureBox.TabStop = false;
            this.OperatorsPictureBox.Visible = false;
            // 
            // functionsSytaxButton
            // 
            this.functionsSytaxButton.Location = new System.Drawing.Point(685, 54);
            this.functionsSytaxButton.Name = "functionsSytaxButton";
            this.functionsSytaxButton.Size = new System.Drawing.Size(75, 38);
            this.functionsSytaxButton.TabIndex = 7;
            this.functionsSytaxButton.Text = "functions\r\nallowed";
            this.functionsSytaxButton.UseVisualStyleBackColor = true;
            this.functionsSytaxButton.Click += new System.EventHandler(this.functionsSytaxButton_Click);
            // 
            // functionsSyntaxLink
            // 
            this.functionsSyntaxLink.AutoSize = true;
            this.functionsSyntaxLink.Location = new System.Drawing.Point(451, 117);
            this.functionsSyntaxLink.Name = "functionsSyntaxLink";
            this.functionsSyntaxLink.Size = new System.Drawing.Size(367, 15);
            this.functionsSyntaxLink.TabIndex = 8;
            this.functionsSyntaxLink.TabStop = true;
            this.functionsSyntaxLink.Text = "https://mathparser.org/mxparser-math-collection/unary-functions/";
            this.functionsSyntaxLink.Visible = false;
            // 
            // syntaxForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(893, 560);
            this.Controls.Add(this.functionsSyntaxLink);
            this.Controls.Add(this.functionsSytaxButton);
            this.Controls.Add(this.OperatorsPictureBox);
            this.Controls.Add(this.FormatsPictureBox);
            this.Controls.Add(this.numberFormartsbutton);
            this.Controls.Add(this.operatorsSytaxbutton);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "syntaxForm";
            this.Text = "syntaxForm";
            ((System.ComponentModel.ISupportInitialize)(this.FormatsPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.OperatorsPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button operatorsSytaxbutton;
        private System.Windows.Forms.Button numberFormartsbutton;
        private System.Windows.Forms.PictureBox FormatsPictureBox;
        private System.Windows.Forms.PictureBox OperatorsPictureBox;
        private System.Windows.Forms.Button functionsSytaxButton;
        private System.Windows.Forms.LinkLabel functionsSyntaxLink;
    }
}