﻿using System;
using System.Collections.Generic;
using System.Text;

namespace numericalProject_20201701903
{
    public static class allowedCharacters
    {
        public static String numerals  = "" ;
        public static String operators  = "";
        public static String varNames  ="";
        public static char[] illegalVarNames  = "abcdefghijklmnopqrstuvwz".ToCharArray();

        static allowedCharacters()
        {
            for (int i = 0; i<10; i++)
            {
                numerals.Insert(i,i.ToString());
            }
            operators = "+-*/=.()^";
            varNames = "xy";
        }
    }
}
