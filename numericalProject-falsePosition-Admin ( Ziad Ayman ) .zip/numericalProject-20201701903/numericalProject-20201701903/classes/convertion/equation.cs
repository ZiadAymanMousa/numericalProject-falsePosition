﻿using System;
using System.Collections.Generic;
using System.Text;
using static numericalProject_20201701903.allowedCharacters;


namespace numericalProject_20201701903
{
    
    class equation
    {
        private struct equationElement
        {
            string variable;
            char operations;
            double equationValues;
        }
        private List<KeyValuePair<int, equationElement>> equationBrokendown { get; }
        private List<KeyValuePair<int,double>> equationValues;
        private List<KeyValuePair<int, char>> operations;
        private List<KeyValuePair<int, char>> variables;
        public equation(string rawInput)
        {

        }
       public static bool equationRegEx(string rawInput)
        {

            return varsFoundRegEx(rawInput) && OperationsFound(rawInput);
        }
        public static bool  varsFoundRegEx(string rawInput)
        {
            bool[] varsfound = new bool[2];
            varsfound[1] = false;
            varsfound[0] = false;

            try
            {
                int tempIndex = rawInput.IndexOfAny(allowedCharacters.illegalVarNames);

                if (tempIndex > -1)
                {
                    throw (new illegalVariableNameException("use valid variable names, or make sure you use ``x``,  ``y``, numbers, valid opperators only. Illegal VariableName found" + rawInput[tempIndex]));
                }

                string[] tempInput = rawInput.Split(allowedCharacters.operators);

                for (int i = 0; i < tempInput.Length; i++)
                {
                    
                    tempIndex = tempInput[i].IndexOfAny(allowedCharacters.varNames.ToCharArray());
                    if (tempIndex > -1)
                    {
                       
                        if (tempInput[i][tempIndex] == 'x' && !varsfound[0])
                        {
                            varsfound[0] = true;
                            continue;
                        }
                        else if (!varsfound[1])
                        {
                            varsfound[1] = true;
                            continue;
                        }
                        else break;

                    } 
                   
                }
                if (!varsfound[0] || !varsfound[1])
                {
                    throw (new missingArgumentsException("variables missing (true means missing) \n x =" + !varsfound[0] + "\n y = " + !varsfound[1]));
                }
            }
            catch (illegalVariableNameException ivne)
            {
                Console.WriteLine("illegalVarNameException", ivne.Message);
                return false;
            }
            catch (missingArgumentsException mae)
            {
                Console.WriteLine("missingArgumentException", mae.Message);
                return false;
            }
           
            return true;
        }
        /// <summary>
        /// returns true if equals is found and all opertation have atleast value before and one value after
        /// </summary>
        /// <param equation string="rawInput"></param>
        /// <returns></returns>
        public static bool OperationsFound(string rawInput)
        {
            int i = 0;
            bool equalFound = false;
            try
            {
                while (i < rawInput.Length)
                {
                    i = rawInput.IndexOfAny(allowedCharacters.operators.ToCharArray());
                    
                    if (!(allowedCharacters.numerals.IndexOf(rawInput[i - 1]) > -1) || i == 0 || !(allowedCharacters.varNames.IndexOf(rawInput[i - 1]) > -1))
                    {
                        throw new missingArgumentsException("syntax error due to missing values before operation " + rawInput[i] + " at position " + i);
                    }
                    else if (!(allowedCharacters.numerals.IndexOf(rawInput[i + 1]) > -1 || i == rawInput.Length || !(allowedCharacters.varNames.IndexOf(rawInput[i + 1]) > -1))){
                        throw new missingArgumentsException("syntax error due to missing values after operation " + rawInput[i] + " at position " + i);
                    }
                    
                    if (!equalFound && rawInput[i] == '=')
                    {
                        equalFound = true;
                    }
                }
                if (!equalFound)
                {
                    throw new missingArgumentsException("syntax error missing operation '='");
                }
                return true;
            }
            catch(missingArgumentsException mae)
            {
                Console.WriteLine("bad syntax error: " + mae.Message);
                return false;
            }
        }
    }

    class illegalVariableNameException: Exception
    {
        public illegalVariableNameException(string message) : base(message)
        {
        }
    }
    class missingArgumentsException : Exception
    {
        public missingArgumentsException(string message) : base(message)
        {
        }
    }
}
