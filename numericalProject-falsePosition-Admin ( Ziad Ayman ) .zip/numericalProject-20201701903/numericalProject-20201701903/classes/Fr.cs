﻿using System;
using System.Collections.Generic;
using System.Text;
using org.mariuszgromada.math.mxparser;
using System.Diagnostics;

namespace numericalProject_20201701903.classes
{    
    class Fr
    {

        public static int MAX_ITER = 1000000 ;
        public static Function equ;
        static int its;
        public static int roundTo = 0;

        static double func(double x)
        {
            double xd = (double)equ.calculate(x);
            Debug.WriteLine(xd);
            return xd;

        }

        public static string checkSyntax(){
            
            if (equ.checkSyntax())
            {
                return "calculating";
            }
            else
            {
                return equ.getErrorMessage();
            }
        }

        public static string falsePoint(double a, double b)
        {
            try
            {
                double temp = func(a) * func(b);
                if ( temp >= 0)
                {
                    throw new Exception ( "You have not assumed right a and b ranges");
                }

                double c = a;

                for (int i = 0; i < MAX_ITER; i++)
                {
                    //false point function
                    c = (a * func(b) - b * func(a))/ (func(b) - func(a)); // (a*fb-b*fa)/ (fb-fa)

                    //root found
                    if (func(c) == 0) break;
                  
                    else if (func(c) * func(a) < 0) b = c;
                    else a = c;

                    its = i+1;
                }

                //whether to round or not from input rounding
                string tempStr;
                if (roundTo > 0)
                {
                     tempStr =""+ Math.Round(c, roundTo);
                    tempStr = tempStr + " rounded to:- " + roundTo + " decimal places \n";
                }
                else
                {
                     tempStr = c+ " ";
                }

                return "The value of root is : " +tempStr + "number of iterations taken:- "+ its;
            }
            catch (Exception e)
            {
                Debug.WriteLine(e.Message);
                return e.Message;
            }          
        }
    }
}
