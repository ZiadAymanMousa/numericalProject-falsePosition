﻿
namespace numericalProject_20201701903
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.equationInputBox = new System.Windows.Forms.TextBox();
            this.falseRegaliaButton = new System.Windows.Forms.Button();
            this.aRangeInputBox = new System.Windows.Forms.TextBox();
            this.bRangeInputBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.MAXITTERS = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.syntaxButton = new System.Windows.Forms.Button();
            this.roundToNumBox = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.MAXITTERS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.roundToNumBox)).BeginInit();
            this.SuspendLayout();
            // 
            // equationInputBox
            // 
            this.equationInputBox.Location = new System.Drawing.Point(274, 138);
            this.equationInputBox.Name = "equationInputBox";
            this.equationInputBox.Size = new System.Drawing.Size(274, 23);
            this.equationInputBox.TabIndex = 0;
            // 
            // falseRegaliaButton
            // 
            this.falseRegaliaButton.Location = new System.Drawing.Point(308, 179);
            this.falseRegaliaButton.Name = "falseRegaliaButton";
            this.falseRegaliaButton.Size = new System.Drawing.Size(147, 23);
            this.falseRegaliaButton.TabIndex = 1;
            this.falseRegaliaButton.Text = "Calculate False Position";
            this.falseRegaliaButton.UseVisualStyleBackColor = true;
            this.falseRegaliaButton.Click += new System.EventHandler(this.falseRegaliaButton_Click);
            // 
            // aRangeInputBox
            // 
            this.aRangeInputBox.Location = new System.Drawing.Point(93, 138);
            this.aRangeInputBox.Name = "aRangeInputBox";
            this.aRangeInputBox.Size = new System.Drawing.Size(72, 23);
            this.aRangeInputBox.TabIndex = 2;
            // 
            // bRangeInputBox
            // 
            this.bRangeInputBox.Location = new System.Drawing.Point(93, 180);
            this.bRangeInputBox.Name = "bRangeInputBox";
            this.bRangeInputBox.Size = new System.Drawing.Size(72, 23);
            this.bRangeInputBox.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(62, 146);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(13, 15);
            this.label1.TabIndex = 4;
            this.label1.Text = "a";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(62, 188);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(14, 15);
            this.label2.TabIndex = 5;
            this.label2.Text = "b";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(274, 104);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(274, 15);
            this.label3.TabIndex = 6;
            this.label3.Text = "insert expression below (use x for variable name) :-";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(93, 89);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 30);
            this.label4.TabIndex = 7;
            this.label4.Text = "insert range \r\n    below";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(283, 243);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 15);
            this.label5.TabIndex = 8;
            // 
            // MAXITTERS
            // 
            this.MAXITTERS.Location = new System.Drawing.Point(93, 243);
            this.MAXITTERS.Name = "MAXITTERS";
            this.MAXITTERS.Size = new System.Drawing.Size(72, 23);
            this.MAXITTERS.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(5, 245);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 15);
            this.label6.TabIndex = 10;
            this.label6.Text = "max iterations";
            // 
            // syntaxButton
            // 
            this.syntaxButton.Location = new System.Drawing.Point(591, 25);
            this.syntaxButton.Name = "syntaxButton";
            this.syntaxButton.Size = new System.Drawing.Size(75, 23);
            this.syntaxButton.TabIndex = 11;
            this.syntaxButton.Text = "Syntax";
            this.syntaxButton.UseVisualStyleBackColor = true;
            this.syntaxButton.Click += new System.EventHandler(this.syntaxButton_Click);
            // 
            // roundToNumBox
            // 
            this.roundToNumBox.Location = new System.Drawing.Point(93, 279);
            this.roundToNumBox.Name = "roundToNumBox";
            this.roundToNumBox.Size = new System.Drawing.Size(72, 23);
            this.roundToNumBox.TabIndex = 12;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(5, 272);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(85, 30);
            this.label7.TabIndex = 13;
            this.label7.Text = "round to \r\ndecimal places\r\n";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(691, 356);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.roundToNumBox);
            this.Controls.Add(this.syntaxButton);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.MAXITTERS);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.bRangeInputBox);
            this.Controls.Add(this.aRangeInputBox);
            this.Controls.Add(this.falseRegaliaButton);
            this.Controls.Add(this.equationInputBox);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.MAXITTERS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.roundToNumBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox equationInputBox;
        private System.Windows.Forms.Button falseRegaliaButton;
        private System.Windows.Forms.TextBox aRangeInputBox;
        private System.Windows.Forms.TextBox bRangeInputBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown MAXITTERS;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button syntaxButton;
        private System.Windows.Forms.NumericUpDown roundToNumBox;
        private System.Windows.Forms.Label label7;
    }
}

